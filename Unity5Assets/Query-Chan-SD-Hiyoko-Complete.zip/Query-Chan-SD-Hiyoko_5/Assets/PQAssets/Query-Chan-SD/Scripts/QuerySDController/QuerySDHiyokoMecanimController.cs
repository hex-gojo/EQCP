using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class QuerySDHiyokoMecanimController : MonoBehaviour {

	[SerializeField]
	GameObject queryBodyParts;
	
	public enum QueryChanSDHiyokoAnimationType
	{
		// Normal Motion
		NORMAL_STAND = 1,
		NORMAL_WALK = 2,
		NORMAL_RUN = 3,
		NORMAL_IDLE = 4,
		NORMAL_DAMAGE = 5,
		NORMAL_ITEMGET = 6,
		NORMAL_LOSE = 7,
		NORMAL_WIN = 8,
		NORMAL_FLY_IDLE = 9,
		NORMAL_FLY_STRAIGHT = 10,
		NORMAL_FLY_LEFT = 11,
		NORMAL_FLY_RIGHT = 12,
		NORMAL_FLY_UP = 13,
		NORMAL_FLY_DOWN = 14,
		NORMAL_FLY_CIRCLE = 15,
		NORMAL_FLY_TURNBACK = 16,

		// Normal Pose
		NORMAL_POSE_CUTE = 50,
		NORMAL_POSE_HELLO = 51,
		NORMAL_POSE_READY = 52,
		NORMAL_POSE_STOP = 53,
		NORMAL_POSE_BOW = 54,
		NORMAL_POSE_ARMCROSSED = 55,
		NORMAL_POSE_PLEASE = 56,
		NORMAL_POSE_SIT = 57,
		NORMAL_POSE_LAYDOWN = 58,
		NORMAL_POSE_ROMANCE = 59,

		// Black Motion
		BLACK_FIGHTING = 105,
		BLACK_PUNCH = 106,
		BLACK_KICK = 107,

		// Black Pose
		BLACK_POSE_1 = 150,
		BLACK_POSE_2 = 151,
		BLACK_POSE_3 = 152,

		// Osaka Motion
		OSAKA_TUKKOMI = 205,
		OSAKA_BOKE = 206,
		OSAKA_CLAP =207,

		// Osaka Pose
		OSAKA_POSE_GOAL = 250,
		OSAKA_POSE_TEHEPERO = 251,
		OSAKA_POSE_EXIT = 252,

		// Fukuoka Motion
		FUKUOKA_DANCE_1 = 305,
		FUKUOKA_DANCE_2 = 306,
		FUKUOKA_WAIWAI =307,
		
		// Fukuoka Pose
		FUKUOKA_POSE_1 = 350,
		FUKUOKA_POSE_2 = 351,
		FUKUOKA_POSE_HIRUNE = 352,

		// Hokkaido Motion
		HOKKAIDO_SNOWBALLING = 405,
		HOKKAIDO_CLIONE = 406,
		HOKKAIDO_IKADANCE = 407,

		// Hokkaido Pose
		HOKKAIDO_POSE_COLD = 450,
		HOKKAIDO_POSE_BEAMBITIOUS = 451,
		HOKKAIDO_POSE_BEAR = 452

	}

	public enum QueryChanSDHiyokoHandType
	{

		NORMAL = 0,
		STONE = 1,
		PAPER = 2

	}

	void Update()
	{
		queryBodyParts.transform.localPosition = Vector3.zero;
		queryBodyParts.transform.localRotation = Quaternion.identity;

	}


	public void ChangeAnimation (QueryChanSDHiyokoAnimationType animNumber, bool isChangeMechanimState=true)
	{

		var emoControl = this.GetComponent<QuerySDHiyokoEmotionalController>();

		switch (animNumber)
		{
		case QueryChanSDHiyokoAnimationType.NORMAL_WIN:
		case QueryChanSDHiyokoAnimationType.NORMAL_ITEMGET:
		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_HELLO:
		case QueryChanSDHiyokoAnimationType.BLACK_POSE_1:
		case QueryChanSDHiyokoAnimationType.OSAKA_CLAP:
		case QueryChanSDHiyokoAnimationType.OSAKA_POSE_GOAL:
		case QueryChanSDHiyokoAnimationType.FUKUOKA_WAIWAI:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_SMILE);
			break;

		case QueryChanSDHiyokoAnimationType.NORMAL_DAMAGE:
		case QueryChanSDHiyokoAnimationType.BLACK_POSE_3:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_GURUGURU);
			break;

		case QueryChanSDHiyokoAnimationType.NORMAL_LOSE:
		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_PLEASE:
		case QueryChanSDHiyokoAnimationType.BLACK_POSE_2:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_SAD);
			break;

		case QueryChanSDHiyokoAnimationType.NORMAL_FLY_CIRCLE:
		case QueryChanSDHiyokoAnimationType.OSAKA_BOKE:
		case QueryChanSDHiyokoAnimationType.OSAKA_POSE_EXIT:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_SURPRISE);
			break;

		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_READY:
		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_LAYDOWN:
		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_ROMANCE:
		case QueryChanSDHiyokoAnimationType.BLACK_KICK:
		case QueryChanSDHiyokoAnimationType.FUKUOKA_DANCE_2:
		case QueryChanSDHiyokoAnimationType.FUKUOKA_POSE_HIRUNE:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_BLINK);
			break;
		
		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_BOW:
		case QueryChanSDHiyokoAnimationType.NORMAL_POSE_ARMCROSSED:
		case QueryChanSDHiyokoAnimationType.BLACK_FIGHTING:
		case QueryChanSDHiyokoAnimationType.OSAKA_TUKKOMI:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_ANGER);
			break;

		default:
			emoControl.ChangeEmotion(QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_DEFAULT);
			break;
		}


		if (isChangeMechanimState) {
			queryBodyParts.GetComponent<Animator>().SetInteger("AnimIndex", (int)animNumber);
		}

	}

}
