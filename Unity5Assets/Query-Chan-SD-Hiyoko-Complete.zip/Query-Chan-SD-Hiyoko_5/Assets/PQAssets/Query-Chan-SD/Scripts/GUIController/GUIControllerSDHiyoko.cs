using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GUIControllerSDHiyoko : MonoBehaviour {

	Vector3 PosDefault;
	[SerializeField]
	GameObject CameraObj;
	private bool cameraUp;
	[SerializeField]
	protected GameObject queryChan;
	private int querySoundNumber;
	private int targetNum;
	List<string> targetSounds = new List<string>();
	
	//===============================

	[SerializeField]
	QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType defaultAnimType = QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_STAND;

	[SerializeField]
	bool showCommon, showNormal;
	
	
	class ButtonInfo {
		public string buttonLabel;
		public int id;
		
		public ButtonInfo(string label, object _id) {
			buttonLabel = label;
			id =  (int)_id;
		}
	}

	private ButtonInfo[] animButtonInfoCommon = {
		// Common animations
		new ButtonInfo("Nomal_Stand",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_STAND),
		new ButtonInfo("Nomal_Walk",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_WALK),
		new ButtonInfo("Nomal_Run",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_RUN),
		new ButtonInfo("Nomal_Idle",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_IDLE),
	};

	private ButtonInfo[] animButtonInfoNormal = {
		// Normal animations
		new ButtonInfo("Nomal_Damage",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_DAMAGE),
		new ButtonInfo("Nomal_ItemGet",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_ITEMGET),
		new ButtonInfo("Nomal_Lose",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_LOSE),
		new ButtonInfo("Nomal_Win",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_WIN),
		new ButtonInfo("Nomal_FlyIdle",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_IDLE),
		new ButtonInfo("Nomal_FlyStraight",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_STRAIGHT),
		new ButtonInfo("Nomal_FlyLeft",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_LEFT),
		new ButtonInfo("Nomal_FlyRight",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_RIGHT),
		new ButtonInfo("Nomal_FlyUp",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_UP),
		new ButtonInfo("Nomal_FlyDown",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_DOWN),
		new ButtonInfo("Nomal_FlyCircle",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_CIRCLE),
		new ButtonInfo("Nomal_FlyTurnback",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_FLY_TURNBACK),
		new ButtonInfo("Nomal_Pose_Cute",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_CUTE),
		new ButtonInfo("Nomal_Pose_Hello",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_HELLO),
		new ButtonInfo("Nomal_Pose_Ready",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_READY),
		new ButtonInfo("Nomal_Pose_Stop",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_STOP),
		new ButtonInfo("Nomal_Pose_Bow",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_BOW),
		new ButtonInfo("Nomal_Pose_ArmCrossed",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_ARMCROSSED),
		new ButtonInfo("Nomal_Pose_Please",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_PLEASE),
		new ButtonInfo("Nomal_Pose_Sit",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_SIT),
		new ButtonInfo("Nomal_Pose_LayDown",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_LAYDOWN),
		new ButtonInfo("Nomal_Pose_Romance",			QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType.NORMAL_POSE_ROMANCE),
	};

	
	// ------------------------------------
	
	private ButtonInfo[] emotionButtonInfo = {
		new ButtonInfo("Default",		QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_DEFAULT),
		new ButtonInfo("Anger",		QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_ANGER),
		new ButtonInfo("Blink",			QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_BLINK),
		new ButtonInfo("Guruguru",			QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_GURUGURU),
		new ButtonInfo("Sad",			QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_SAD),
		new ButtonInfo("Smile",		QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_SMILE),
		new ButtonInfo("Surprise",			QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType.NORMAL_SURPRISE),
	};
	
	//==============================
	
	
	
	void Start() {
		
		PosDefault = CameraObj.transform.localPosition;
		cameraUp = false;
		querySoundNumber = 0;
		
		foreach (AudioClip targetAudio in queryChan.GetComponent<QuerySDHiyokoSoundController>().soundData)
		{
			targetSounds.Add(targetAudio.name);
		}
		targetNum = targetSounds.Count - 1;
		
		ChangeAnimation((int)defaultAnimType);
		
	}
	
	void OnGUI(){
		
		//AnimationChange ------------------------------------------------
		float animButtonHeight = Screen.height/ (animButtonInfoCommon.Length + animButtonInfoNormal.Length  +1) -3;
		
		
		GUILayout.BeginHorizontal(GUILayout.Width(Screen.width/4));
			
			GUILayout.BeginVertical();
			
				if (showCommon) 	{ ShowAnimationButtons(animButtonInfoCommon, 	animButtonHeight); }
				if (showNormal) 	{ ShowAnimationButtons(animButtonInfoNormal, 	animButtonHeight); }
			
			GUILayout.EndVertical();
			
		GUILayout.EndHorizontal();
		
		
		//FaceChange ------------------------------------------------
		float emotionButtonHeight =  (Screen.height-200) / (emotionButtonInfo.Length+1) - 3;
		
		GUILayout.BeginArea(new Rect(Screen.width- Screen.width/4, 0, Screen.width/4, Screen.height-200));
			
			GUILayout.BeginVertical();
				
				foreach (var tmpInfo in emotionButtonInfo) {
					if (GUILayout.Button(tmpInfo.buttonLabel, GUILayout.Height(emotionButtonHeight))) {
						ChangeFace((QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType)tmpInfo.id);
					}
				}
			
			GUILayout.EndVertical();
		
		GUILayout.EndArea();
		
		
		//CameraChange --------------------------------------------
		
		if (GUI.Button (new Rect (Screen.width / 2 -75, 0, 150, 80), "Camera"))
		{
			if (cameraUp == true)
			{
				CameraObj.GetComponent<Camera>().fieldOfView = 60;
				CameraObj.transform.localPosition = new Vector3(PosDefault.x, PosDefault.y, PosDefault.z);
				cameraUp = false;
			}
			else
			{
				CameraObj.GetComponent<Camera>().fieldOfView = 25;
				CameraObj.transform.localPosition = new Vector3(PosDefault.x, PosDefault.y + 0.1f, PosDefault.z);
				cameraUp = true;
			}
		}
		
		
		//Sound ---------------------------------------------------------
		
		if(GUI.Button(new Rect(Screen.width / 2 - 150, Screen.height - 100, 50 ,100), "<---"))
		{
			querySoundNumber--;
			if (querySoundNumber < 0)
			{
				querySoundNumber = targetNum;
			}
		}
		if(GUI.Button(new Rect(Screen.width / 2 + 100, Screen.height - 100, 50 ,100), "--->"))
		{
			querySoundNumber++;
			if (querySoundNumber > targetNum)
			{
				querySoundNumber = 0;
			}
			
		}
		if(GUI.Button(new Rect(Screen.width / 2 - 100, Screen.height - 70, 200 ,70), "Play"))
		{
			queryChan.GetComponent<QuerySDHiyokoSoundController>().PlaySoundByNumber(querySoundNumber);
		}
		
		GUI.Label (new Rect(Screen.width / 2 - 100, Screen.height - 100, 200, 30), (querySoundNumber+1) + " / " + (targetNum+1) + "  :  " + targetSounds[querySoundNumber]);

		
	}
	
	
	void ShowAnimationButtons(ButtonInfo[] infos, float buttonHeight)
	{
		foreach (var tmpInfo in infos) {
			if ( GUILayout.Button(tmpInfo.buttonLabel, GUILayout.Height(buttonHeight)) ){
				ChangeAnimation(tmpInfo.id);
			}
		}
	}
	
	
	void ChangeFace (QuerySDHiyokoEmotionalController.QueryChanSDHiyokoEmotionalType faceNumber) {
		
		queryChan.GetComponent<QuerySDHiyokoEmotionalController>().ChangeEmotion(faceNumber);
		
	}
	

	void ChangeAnimation (int animNumber)
	{
		queryChan.GetComponent<QuerySDHiyokoMecanimController>().ChangeAnimation((QuerySDHiyokoMecanimController.QueryChanSDHiyokoAnimationType)animNumber);
	}

}
